<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    if(session("username")!=null)
        redirect("home");
    else
        return view('welcome');
});

Route::get('/register', "App\Http\Controllers\RegisterController@index")->name("register");
Route::get('/register/valid', "App\Http\Controllers\RegisterController@create")->name("validation");
Route::post('/register', "App\Http\Controllers\RegisterController@create");


Route::get('/login', "App\Http\Controllers\LoginController@index")->name("login");
Route::post('/login', "App\Http\Controllers\LoginController@login")->name("control");
Route::get('/logout', "App\Http\Controllers\loginController@logout")->name("logout");

Route::get('/home', "App\Http\Controllers\HomeController@index")->name("home");
Route::get('/homedata', "App\Http\Controllers\HomeController@data")->name("homedata");

Route::get('/overlay', "App\Http\Controllers\OverlayController@create")->name("overlay");

Route::get('/modificaLike', "App\Http\Controllers\LikesController@modify")->name("modificaLike");

Route::get('/aggiungiCommento', "App\Http\Controllers\CommentsController@add")->name("aggiungiCommento");
Route::get('/eliminaCommento', "App\Http\Controllers\CommentsController@remove")->name("eliminaCommento");

Route::get('/InserimentoLocale', "App\Http\Controllers\InsertController@local")->name("InserimentoLocale");

Route::get('/Carrello', "App\Http\Controllers\CarrelloController@index")->name("carrello");
Route::get('/carrelloDati', "App\Http\Controllers\CarrelloController@data")->name("carrelloDati");
Route::get('/EliminazioneCarrello', "App\Http\Controllers\CarrelloController@remove")->name("carrelloDati");
Route::get('/cambiaQuantita', "App\Http\Controllers\CarrelloController@change")->name("carrelloDati");
Route::get('/pubblica', "App\Http\Controllers\CarrelloController@pubblica")->name("pubblica");
Route::get('/eliminaCarrello', "App\Http\Controllers\CarrelloController@eliminaCarrello")->name("eliminaCarrello");

Route::get('/Ricerca', "App\Http\Controllers\SearchController@index")->name("ricerca");
Route::post('/Ricerca', "App\Http\Controllers\SearchController@session")->name("sessione");

Route::get('/Curl', "App\Http\Controllers\InsertController@curl")->name("curl");
Route::get('/InserimentoCarrello', "App\Http\Controllers\SearchController@inserimento")->name("ricerca");

Route::get('/Profilo', "App\Http\Controllers\ProfileController@index")->name("Profilo");
Route::get('/profiloData', "App\Http\Controllers\ProfileController@data")->name("profiloData");
Route::get('/cambiaFollow', "App\Http\Controllers\ProfileController@cambiaFollow")->name("cambiaFollow");
Route::post('/uploadPhoto', "App\Http\Controllers\ProfileController@uploadPhoto")->name("uploadPhoto");
