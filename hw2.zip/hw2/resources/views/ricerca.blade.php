@extends('layouts.page', ['img' => $img,"username"=>$username])  
@section("placeholder")
"Cerca Prodotto"
@endsection
@section("action")
/Ricerca
@endsection
@section("titolo")
<title>
        Ricerca
</title>
@endsection  
@section("css_js")
    <link rel="stylesheet" href="{{ asset('css/Ricerca.css') }}">
    <script src=" {{asset('js/Ricerca.js')}}" defer="true"></script>
@endsection
@section("corpo")
<article>

        
    <img id="caricamento" src="images/caricamento.gif">
        
        
        
    </article>
@endsection




