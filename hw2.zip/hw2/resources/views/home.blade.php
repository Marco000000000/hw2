@extends('layouts.page', ['img' => $img,"username"=>$username])  
@section("placeholder")
"Cerca carrello"
@endsection
@section("action")
/home
@endsection
@section("titolo")
<title>
        Home
</title>
@endsection  
@section("css_js")
    <link rel="stylesheet" href="{{ asset('css/overlay.css') }}">
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
    <script src=" {{asset('js/home.js')}}" defer="true"></script>
@endsection
@section("corpo")
<article>
</article>
@endsection










