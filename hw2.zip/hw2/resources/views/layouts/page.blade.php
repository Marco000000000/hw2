<html>

<head>
    @yield("titolo")
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @yield("css_js")

    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
</head>
<body>
    

    <nav>
             
        <a href="/home"><div>Home</div> </a>
      
     <form action='@yield("action")' method="post">
     @csrf

        <svg width="30" height="30" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Zm10.45 2.95L16 16l4.95 4.95Z" class="icon_svg-stroke" stroke="#666" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"></path></svg>
         <label> <input type="text" placeholder=@yield("placeholder") name="cerca"></label>
      </form>
     <!--<div >
         <a href="logout.php"> Accedi </a>
         <a href="Registrazione.php"> Registrati</a>
      </div>
     -->
     
     
     
     <div id="right">
         <a id="icona" href="/Carrello">🛒        </a>
         <div id="username"> <img src="{{ $img }}">
             <div id="nav_hidden">
                <a href="Profilo">{{$username}}</a>
                 <a   href="/logout">Logout</a> 
             </div>
         
         </div>
         
      </div>

 </nav>

        
    
 @yield("corpo")

</body>

</html>   