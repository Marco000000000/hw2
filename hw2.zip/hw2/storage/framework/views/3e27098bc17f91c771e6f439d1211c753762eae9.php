  
<?php $__env->startSection("placeholder"); ?>
"Cerca persona o argomento"
<?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?>
""
<?php $__env->stopSection(); ?>
<?php $__env->startSection("titolo"); ?>
<title>
        Profilo
</title>
<?php $__env->stopSection(); ?>  
<?php $__env->startSection("css_js"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/overlay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Profilo.css')); ?>">
    <script src=" <?php echo e(asset('js/Profilo.js')); ?>" defer="true"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("corpo"); ?>
<header>
        <div class="profilo">
            <form target="_myFrame" action="" method="post">
            <?php echo csrf_field(); ?>
            <label><input class="hidden" name="foto" type="file"></input><img class="manina" src="<?php echo e($img); ?>"></label>
            
            </form>
            <div class="dati">
                <h1> <?php echo e($username); ?></h1>
                <div class="segui">
                    <p></p>
                    <button><strong>👤</strong></button>
                </div>
                
            </div>
        </div>
        <div class="scelta">
            <div id="pub" class="selected"><a >Pubblicati</a></div>
            <div id="like"><a>Piaciuti</a></div>
            <div id="follow"><a>Seguiti</a></div>
            
        </div>

    </header>
    <article>
    


         
    </article>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.page', ['img' => $img,"username"=>$username], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Utente\provalaravel\yourproject\resources\views/profilo.blade.php ENDPATH**/ ?>