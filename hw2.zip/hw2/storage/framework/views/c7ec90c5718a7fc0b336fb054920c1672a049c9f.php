
<html>

<head>
    <title>
        Home
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/overlay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
   
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <script src="<?php echo e(asset('js/index.js')); ?>" defer="true"></script>

</head>
<body>
    

    <nav>
             
        <a href="home"><div>Home</div> </a>
      
     <form action="Ricerca">
        <svg width="30" height="30" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Zm10.45 2.95L16 16l4.95 4.95Z" class="icon_svg-stroke" stroke="#666" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"></path></svg>

         <label> <input type="text" placeholder="Cerca carrello" name="cerca"></label>
      </form>
     <!--<div >
         <a href="logout"> Accedi </a>
         <a href="Registrazione"> Registrati</a>
      </div>
     -->
     
     
     
     <div id="right">
         <a id="icona" href="Carrello">🛒        </a>
         <div id="username"> <img src="images/profilo-vuoto.png">
             <div id="nav_hidden">
                <a href="/login"> Accedi </a>
                <a href="/register"> Registrati</a>
             </div>
         
         </div>
         
      </div>

 </nav>

        
    
    <article>
         
    </article>

</body>

</html>            

   








<?php /**PATH C:\Users\Utente\provalaravel\yourproject\resources\views/welcome.blade.php ENDPATH**/ ?>