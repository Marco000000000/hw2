  
<?php $__env->startSection("placeholder"); ?>
"Cerca carrello"
<?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?>
/home
<?php $__env->stopSection(); ?>
<?php $__env->startSection("titolo"); ?>
<title>
        Home
</title>
<?php $__env->stopSection(); ?>  
<?php $__env->startSection("css_js"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/overlay.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <script src=" <?php echo e(asset('js/home.js')); ?>" defer="true"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("corpo"); ?>
<article>
</article>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.page', ['img' => $img,"username"=>$username], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Utente\provalaravel\yourproject\resources\views/home.blade.php ENDPATH**/ ?>