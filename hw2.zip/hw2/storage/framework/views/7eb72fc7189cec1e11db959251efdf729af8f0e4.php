  
<?php $__env->startSection("placeholder"); ?>
"Cerca Prodotto"
<?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?>
/Ricerca
<?php $__env->stopSection(); ?>
<?php $__env->startSection("titolo"); ?>
<title>
        Carrello
</title>
<?php $__env->stopSection(); ?>  
<?php $__env->startSection("css_js"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/Carrello.css')); ?>">
    <script src=" <?php echo e(asset('js/Carrello.js')); ?>" defer="true"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("corpo"); ?>
<article>
        
        <div class="divisore">
       
        </div>


         <section class="totale">
            <div>
                <p>
                    <strong>Totale:&nbsp</strong><em><?php ?>€</em>
                </p>
            </div>
            <div class="pubblica">
                <p class="errore hidden">Superato il limite dei 255 caratteri</p>
                <form>
                <input row="2"  id="nome" name="nome" type="text" placeholder="Nome carrello" required>
                <textarea id="descrizione" name="descrizione" placeholder="Descrizione" rows="10" cols="50" required></textarea>
                <input id="pubblica" name="pubblica" type="submit" value="Pubblica">

                
            </form>
            </div>
            
        </section>
        
    </article>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.page', ['img' => $img,"username"=>$username], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Utente\provalaravel\yourproject\resources\views/carrello.blade.php ENDPATH**/ ?>