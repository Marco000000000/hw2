<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Profilo extends Model {

    protected $table = 'profilo';
    public $timestamps = false;
    protected $primarykey="Username";
    protected $fillable = [
        'Username', 'Password', 'Email','ImmagineProfilo','carrelloCorrente','seguaci'
    ];

    protected $hidden = [
        'Email', 'Password'
    ];

    protected $casts = [
        'seguaci' => 'int' ,
        'carrelloCorrente' => 'int'
    ];
  
    public function proprietario() {
        return $this->hasMany("App\Models\Carrello","ID");
    }

}

?>