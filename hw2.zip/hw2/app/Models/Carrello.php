<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Carrello extends Model {

    protected $table = 'carrello';
    public $timestamps = false;
    protected $primarykey="ID";
    protected $fillable = [
        'Totale','ID', 'data' ,'proprietario','likes','Descrizione','Nome'
    ];


    

    public function proprietario() {
        return $this->belongsTo("App\Models\Profilo","Username","proprietario");
    }


    public function commenti() {
        return $this->hasMany("App\Models\Commenti","id");
    }
    public function piaciuti() {
        return $this->hasMany("App\Models\Piaciuti",["mittente","carrello"]);
    }

}

?>