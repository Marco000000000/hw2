<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prodotto_carrello extends Model {
    public $timestamps = false;

    protected $table = 'prodotto-carrello';

    protected $fillable = [
        'prodotto', 'carrello', 'quantita'
    ];



    protected $casts = [
        'content' => 'int'
    ];
    public function prodotto(){
        return $this->belongsTo("App\Models\Prodotti","url","prodotto");

    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","ID","carrello");
    }
}

?>