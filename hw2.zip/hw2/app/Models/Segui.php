<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Segui extends Model {

    protected $table = 'segui';
    public $timestamps = false;

    protected $fillable = [
        'seguace', 'seguito'
    ];


    public function seguito() {
        return $this->belongsTo("App\Models\Profilo","Username","seguito");
    }
    public function seguace() {
        return $this->belongsTo("App\Models\Profilo","Username","seguace");
    }

}

?>