<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Piaciuti extends Model {

    protected $table = 'piaciuti';
    public $timestamps = false;
    protected $fillable = [
        'mittente', 'carrello'
    ];


    public function mittente() {
        return $this->belongsTo("App\Models\Profilo","Username","mittente");
    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","ID","carrello");
    }
}

?>