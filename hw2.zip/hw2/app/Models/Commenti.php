<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Commenti extends Model {

    protected $table = 'commenti';
    public $timestamps = false;
    protected $primarykey="id";
    protected $fillable = [
        'mittente', 'carrello', 'commento','id'
    ];

    public function mittente() {
        return $this->belongsTo("App\Models\Profilo","Username","mittente");
    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","ID","carrello");
    }
}

?>