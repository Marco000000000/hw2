<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Prodotti;
use App\Models\Prodotto_carrello;
use App\Models\Carrello;
use App\Models\Piaciuti;
use Illuminate\Support\Facades\Cookie;

use Illuminate\Support\Facades\Session;

class SearchController extends Controller {


    public function session()
    {   
        $request=request();
        if($request->has("cerca"))
        {
            Session::put('cerca',$request->cerca);
            return redirect("Ricerca");
        }
    }
    public function inserimento() {
        $request=request();

        if($request->has("descrizione") &&$request->has("prezzo") &&$request->has("venditore") &&$request->has("link") &&$request->has("img") )
        { $descrizione=$request->descrizione;
            $prezzo=$request->prezzo;
            $img=$request->img;
            $link=$request->link;
            $venditore=$request->venditore;
            $res1=Prodotti::where("url",$link)->exists();
            if(!$res1)
            Prodotti::create([
                'url' => $link,
                'Venditore' => $venditore,
                'titolo' => $descrizione,
                'prezzo' => $prezzo,
                'UrlImg' => $img,
            ]);
            $carrelloCorrente=Profilo::where("Username",session("username"))->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];
            $exist=Prodotto_carrello::where("prodotto",$link)->where("carrello",$carrelloCorrente)->exists();
            if(!$exist)
            Prodotto_carrello::create([
                'prodotto' => $link,
                'carrello' => $carrelloCorrente
            ]);
            return 1;
        }
        return 0;
    
    }

   
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::select("ImmagineProfilo as img")->where("Username",session("username"))->first();
            if($img["img"]!=null)
            {
                $img=$img["img"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('Ricerca',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return redirect('/');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("Ricerca");
            }
        } 

}
?>