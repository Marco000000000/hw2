<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Commenti;

use Illuminate\Support\Facades\Session;

class CommentsController extends Controller {


    protected function add()
    {
        $request = request();
        if($request->has("commento")&&$request->has("carrello") &&session("username")!=null)
        {   $carrello=$request->carrello;
            $commento=$request->commento;
                Commenti::create([
                    'mittente' => session("username"),
                    'carrello' => $carrello,
                    'commento' => $commento
                  ]);
                  return 1;
        }
        else
            
            return 0;        
        
    }

    protected function remove()
    {
        $request = request();
        if($request->has("id")&&$request->has("user") &&session("username")!=null)
        {   $carrello=$request->carrello;
            $id=$request->id;
            if($request->user!=session("username"))
                return 0;

            Commenti::where("id",$id)->delete();
            return 1;
        }
        else
            
            return 0;        
        
    }

   
    
     

}
?>