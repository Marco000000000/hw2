<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cookie;


class LoginController extends Controller {


    public function login()
    {
        $request = request();
        if($request->has('utente')&&$request->has('password'))
            {        
            
            if(($this->checkUsername($request->utente)||$this->checkEmail($request->email))&&$this->check($request) !== 0) 
            {   
                if(Profilo::where('Username', $request->utente)->where("Password",$request->password)->exists())
                {
                    if($request->has("check"))
                    Cookie::queue('username', $request->utente, 24);//Cookie::get('name')
                    Session::put('username', $request->utente);
                    return redirect("home");
                }
                else
                {
                    return view('login',["error" => '<p id="errore_sbagliato" class="errore">Password non corretta</p>']);
                    }
            }
            else{
                return view('login',["error" => '<p id="errore_sbagliato" class="errore">Utente o email non riconosciute</p>']);
            }

        }
        return "";
            
           
        
    }

    private function contains($str,$chars) {
        //print_r([$str,$chars]);
        for($i=0;$i<strlen($chars);$i++)
        {   
            if(strpos($str,$chars[$i])!==false)
            {
                return true;
            }
        }
        return false;
    }
    private function check($data) {
        $specialChars = "/ [`!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?~]/;";
        $num="0123456789";
        $letters="abcdefghijklmnopqrstuvwxyz";

        if((!$this->contains($data->utente,$specialChars))&& (($this->contains($data->password,$num))&&($this->contains(strtolower($data->password),$letters))))
            return true;
        else
            return false;
    
    }
    public function logout() {
        Session::flush();

        $cookie = Cookie::forget('username');
        return redirect('/')->withCookie($cookie);
    }

    public function checkUsername($query) {
        $exist = Profilo::where('Username', $query)->exists();
        return $exist;
    }

    public function checkEmail($query) {
        $exist = Profilo::where('Email', $query)->exists();
        return  $exist;
    }

    public function index() {
        if(session("username")==null)
            if(Cookie::get('username')==null)
                return view('login',["error" => ""]);
            else
            {
                Session::put('username', Cookie::get('username'));
                return  redirect("home");
            }
        else
        {
            return redirect("home") ; 
        }   
        } 

}
?>