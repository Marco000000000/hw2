<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cookie;

class RegisterController extends Controller {


    protected function create()
    {
        $request = request();
        if(!$this->checkUsername($request->utente)&&!$this->checkEmail($request->email)&&$this->check($request) ) {
            $newUser =  Profilo::create([
            'Username' => $request['utente'],
            'Password' => $request['password'],
            'Email' => $request['email'],
            ]);
            if ($newUser) {
                Session::put('username', $newUser->Username);
                return 1;
            } 
            else {
                return 0;
            }
        }
        else 
            return 0;
        
    }

    private function contains($str,$chars) {
        //print_r([$str,$chars]);
        for($i=0;$i<strlen($chars);$i++)
        {   
            if(strpos($str,$chars[$i])!==false)
            {
                return true;
            }
        }
        return false;
    }
    private function check($data) {
        $specialChars = "/ [`!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?~]/;";
        $num="0123456789";
        $letters="abcdefghijklmnopqrstuvwxyz";

        if((!$this->contains($data->utente,$specialChars))&& (($this->contains($data->password,$num))&&($this->contains(strtolower($data->password),$letters))))
            return true;
        else
            return false;
    
    }

    public function checkUsername($query) {
        $exist = Profilo::where('Username', $query)->exists();
        return $exist;
    }

    public function checkEmail($query) {
        $exist = Profilo::where('Email', $query)->exists();
        return  $exist;
    }

    public function index() {
        if(session("username")==null)
            if(Cookie::get('username')==null)
                return view('register');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("home");
            }
            else
        {
            return redirect("home") ; 
        }   
    }

}
?>