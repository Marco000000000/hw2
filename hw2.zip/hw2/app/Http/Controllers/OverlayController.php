<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Prodotti;
use App\Models\Commenti;

use Illuminate\Support\Facades\Session;

class OverlayController extends Controller {


    protected function create()
    {
        $request = request();
        $id=$request->id;
        $res=Prodotti::join('prodotto-carrello', 'url', '=', 'prodotto')
        ->join("carrello","id","=","carrello")
        ->join("profilo","proprietario","=","username")
        ->where("id",$id)
        ->get();
        $data=[];
        $totale=0;
        $cont=0;

        foreach($res as $row)
        {
            $data["titolo"]=$row["Nome"];
            $data["descrizione"]=$row["Descrizione"];
            $dato=[];
            $dato["Venditore"]=$row["Venditore"];
            $dato["url"]=$row["url"];
            $dato["UrlImg"]=$row["UrlImg"];
            $dato["titolo"]=$row["titolo"];
            $dato["prezzo"]=$row["prezzo"];
            $dato["quantita"]=$row["quantita"];

                    
            $totale=$totale+$row["quantita"]*$row["prezzo"];
                    
            $data[$cont]=$dato;
            $cont++;
        }

        $data["length"]=$cont;
        $res=Commenti::where("carrello",$id)->get();
        $commenti=[];
        $cont=0;
        foreach($res as $row)
            {  
                $commento["id"]=$row["id"];
                $commento["mittente"]=$row["mittente"];
                $commento["commento"]=$row["commento"];
                
                $commenti[$cont]=$commento;
                $cont++;
            }
        $commenti["length"]=$cont;
        $data["commenti"]=$commenti;
        $data["totale"]=number_format($totale,2);

        return($data);
        
    }

   
    
     

}
?>