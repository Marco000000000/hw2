<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Carrello;
use App\Models\Piaciuti;
use Illuminate\Support\Facades\Cookie;

use Illuminate\Support\Facades\Session;

class HomeController extends Controller {


    protected function data()
    {
        $request = request();

        $res=Carrello::join('prodotto-carrello', 'ID', '=', 'carrello')
        ->whereNotNull('Nome')
        ->where("Nome",'like',"%$request->cerca%")
        ->orwhere("Descrizione","like","%$request->cerca%")
        ->groupBy('ID')
        ->orderBy("data", "desc")
        ->orderBy("proprietario")
        ->orderBy("ID","desc")
        ->get();
        $data=[];
        $contatore=0;

        foreach($res as $row)
        {   $dato=[];
            $ImmagineProfilo=Profilo::select("ImmagineProfilo")
            ->where("Username",$row->proprietario)->first();
            $dato["carrello"]=$row["carrello"];
            $dato["ImmagineProfilo"]=$ImmagineProfilo;
            $dato["proprietario"]=$row["proprietario"];
            $dato["Totale"]=$row["Totale"];
            $dato["Nome"]=$row["Nome"];
            $dato["likes"]=$row["likes"];
            $dato["ImmagineProfilo"]=$ImmagineProfilo["ImmagineProfilo"];
            if(session("username")!=null)
            {
                $reslike=Piaciuti::where("mittente",session("username"))->where("carrello",$row->carrello)->exists();
                if($reslike)
                {
                    $dato["emoji"]="❤️";
                }
                else{
                    $dato["emoji"]="🤍";
                }
            }
            $dato["tempo"]=$this->tempo($row->data);
            
            $resimg=Carrello::join("prodotto-carrello","ID","=","carrello")
            ->join("prodotti","url","=","prodotto")
            ->whereNotNull('Nome')
            ->where("carrello",$row->carrello)

            
            ->where(function($query) use ($request){
                $query->where("Nome",'like',"%$request->cerca%")
                ->orwhere("Descrizione","like","%$request->cerca%");
        
            })
            ->get();
            $foto=[];
            $link=[];
            $cont=0;
            foreach($resimg as $rowimg){
                $foto["img".$cont]=$rowimg["UrlImg"];
                $link["url".$cont]=$rowimg["url"];
                $cont++;
            }
            $dato["numElementi"]=$cont;
            $dato["foto"]=$foto;
            $dato["link"]=$link;


            $data[$contatore]=$dato;
            $contatore++;

        }
        return($data);
        
    }

   
    private function tempo($data)
    {
        $timestamp=strtotime($data);
        
        $strTime = array("s", "m", "h", "d", "m", "y");
        $length = array("60","60","24","30","12","10");

        $currentTime = time();
        if($currentTime >= $timestamp) {
            $diff     = time()- $timestamp;
            for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
            $diff = $diff / $length[$i];
            }

        $diff = round($diff);
        $diff=$diff . " " . $strTime[$i];
        return $diff;
    }
    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::select("ImmagineProfilo as img")->where("Username",session("username"))->first();
            if($img["img"]!=null)
            {
                $img=$img["img"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('home',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return redirect('/');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("home");
            }
        } 

}
?>