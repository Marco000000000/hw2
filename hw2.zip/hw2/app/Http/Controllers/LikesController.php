<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Piaciuti;

use Illuminate\Support\Facades\Session;

class LikesController extends Controller {


    protected function modify()
    {
        $request = request();
        if($request->has("carrello") &&session("username")!=null)
        {   $carrello=$request->carrello;
            $exist=Piaciuti::where("mittente",session("username"))->where("carrello",$carrello)->exists();
            if($exist)
            {
                Piaciuti::where("mittente",session("username"))->where("carrello",$carrello)->delete();
                
            }
            else{
                Piaciuti::create([
                    'mittente' => session("username"),
                    'carrello' => $carrello,
                  ]);
            }
            return 1;
        }
        return 0;        
        
    }

   
    
     

}
?>