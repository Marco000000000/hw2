<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Carrello;
use App\Models\Piaciuti;
use App\Models\Segui;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller {


    protected function data()
    {
        $request = request();
         if($request->has("cerca")&&$request->has("opzione"))
         {  $query1="";
            $username=$request->cerca;
            $opzione=$request->opzione;
            $queryPrincipale=Profilo::where("username",$username);
            if($queryPrincipale->exists())
            {
                $row=$queryPrincipale->first();
                $username=$row["Username"];
                $imgprofilo=$row["ImmagineProfilo"];
            }
            else {
                $queryalternativa=Carrello::join("profilo","Username","=","proprietario")
                ->whereNotNull("Nome")
                ->where("Nome",'like',"%$request->cerca%")
                ->where(function($query) use ($request){
                $query->orwhere("Descrizione","like","%$request->cerca%");
        
                })
                ->groupBy('Username')
                ->orderBy(DB::raw('count(id)', 'DESC'));
                if($queryalternativa->exists())
                {
                    $row=$queryalternativa->first();
                    $username=$row["Username"];
                    $imgprofilo=$row["ImmagineProfilo"];
                }
                else
                {
                    return 0;
                }

            }
            if($opzione=="pub")
            {
                $query1=Carrello::join("prodotto-carrello","ID","=","carrello")
                ->where("proprietario",$username)
                ->whereNotNull("Nome")
                ->groupBy("carrello")
                ->orderBy("data","desc");
            }
            else{
                if($opzione=="like")
                    {$carrelli=Profilo::select("carrello")->join("piaciuti","mittente","=","Username")->where("Username",$username)->get();
                    $query1=Carrello::join("prodotto-carrello","ID","=","carrello")
                    ->whereIn("carrello",$carrelli)
                    ->whereNotNull("Nome")->groupBy("carrello")->orderBy("data","desc");}
                else
                    if($opzione=="follow")
                        {
                        $proprietario=Profilo::select("seguito")
                        ->join("segui","seguace","=","Username")
                        ->where("Username",$username)->get();
                        $query1=Carrello::join("prodotto-carrello","ID","=","carrello")
                        ->whereIn("proprietario",$proprietario)
                        ->whereNotNull("Nome")->groupBy("carrello")->orderBy("data","desc");
                    }
                    else
                        return 0;
            }

            $conta=Segui::where("seguito",$username)->count();
            $queryFollower=Segui::where("seguace",session("username"));
            $data=[];
            $data["follower"]=$conta;
            if($queryFollower->exists())
            {
                $data["followed"]=true;
            }
            else
            {
                $data["followed"]=false;

            }
            $data["imgProfilo"]=$imgprofilo;
            $data["username"]=$username;
            $contatore=0;
            $res=$query1->get();
            foreach( $res as $row)
            {
                $ImmagineProfilo=Profilo::select("ImmagineProfilo")->where("Username",$row["proprietario"])->first();

                

                $dato["carrello"]=$row["carrello"];
                $dato["ImmagineProfilo"]=$ImmagineProfilo;
                $dato["proprietario"]=$row["proprietario"];
                $dato["Totale"]=$row["Totale"];
                $dato["Nome"]=$row["Nome"];
                $dato["likes"]=$row["likes"];
                $dato["ImmagineProfilo"]=$ImmagineProfilo["ImmagineProfilo"];
                if(session("username")!=null)
                {
                    $reslike=Piaciuti::where("mittente",session("username"))->where("carrello",$row->carrello)->exists();
                    if($reslike)
                    {
                        $dato["emoji"]="❤️";
                    }
                    else{
                        $dato["emoji"]="🤍";
                    }
                }
                $dato["tempo"]=$this->tempo($row->data);
                
                $resimg=Carrello::join("prodotto-carrello","ID","=","carrello")
                ->join("prodotti","url","=","prodotto")
                ->whereNotNull('Nome')
                ->where("carrello",$row->carrello)
                ->orderBy("carrello","desc")
                ->get();
                
                $foto=[];
                $link=[];
                $cont=0;
                foreach($resimg as $rowimg){
                    $foto["img".$cont]=$rowimg["UrlImg"];
                    $link["url".$cont]=$rowimg["url"];
                    $cont++;
                }
                $dato["numElementi"]=$cont;
                $dato["foto"]=$foto;
                $dato["link"]=$link;
    
    
                $data[$contatore]=$dato;
                $contatore++;
    
            }
            $data["length"]=$contatore;
            return($data);
         }

         
    }

    public function cambiaFollow()
    {
        $request = request();
         if($request->has("seguito")&&session("username")!=null)
         {  $user=session("username");
            $seguito=$request->seguito;
            $exists= Segui::where("seguace",$user)->where("seguito",$seguito)->exists();
            if($user==$seguito)
            {
                return 0;
            }
            if(!$exists)
            {
                Segui::create(['seguace' => $user,
                'seguito' => $seguito]);
            }
            else
            {
                Segui::where("seguace",$user)->where("seguito",$seguito)->delete();
            }
            return 1;
        }
        return 0;

    }
    public function uploadPhoto()
    {
        $request = request();
        if($request->hasFile("foto"))
        {   $url=session("username").".".$request->foto->extension();
            $valid_ext = array("jpg","png","jpeg","bmp","gif");

            if(in_array($request->foto->extension(),$valid_ext))
            {
                Profilo::where("Username",session("username"))->update(['ImmagineProfilo' => "upload/".$url]);
                $request->file("foto")->storeAs('upload',$url, 'public_uploads');
                return 1;
            }

       }
        return 0;
    }
    private function tempo($data)
    {
        $timestamp=strtotime($data);
        
        $strTime = array("s", "m", "h", "d", "m", "y");
        $length = array("60","60","24","30","12","10");

        $currentTime = time();
        if($currentTime >= $timestamp) {
            $diff     = time()- $timestamp;
            for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
            $diff = $diff / $length[$i];
            }

        $diff = round($diff);
        $diff=$diff . " " . $strTime[$i];
        return $diff;
    }
    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::select("ImmagineProfilo as img")->where("Username",session("username"))->first();
            if($img["img"]!=null)
            {
                $img=$img["img"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('profilo',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return redirect('/');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("profilo");
            }
        } 

}
?>