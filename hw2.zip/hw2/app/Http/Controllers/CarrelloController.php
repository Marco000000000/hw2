<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Prodotti;
use App\Models\Carrello;
use App\Models\Profilo;
use App\Models\Prodotto_carrello;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\DB;

class CarrelloController extends Controller {


    protected function data()
    {
        $request = request();
        if($request->username==session("username"))
        {
            $username=$request->username;
            $data=[];

            $res=Prodotti::join("prodotto-carrello","url","=","prodotto")
            ->join("carrello","id","=","carrello")
            ->join("profilo","id","=","carrelloCorrente")
            ->where("proprietario","$username")->get();
            $totale=0;
            $cont=0;
            foreach( $res as $row)
            {    
                
                $dato=[];
                $dato["Venditore"]=$row["Venditore"];
                $dato["url"]=$row["url"];
                $dato["UrlImg"]=$row["UrlImg"];
                $dato["titolo"]=$row["titolo"];
                $dato["prezzo"]=$row["prezzo"];
                $dato["quantita"]=$row["quantita"];

        
                        
                $totale=$totale+$row["quantita"]*$row["prezzo"];
                
                $data[$cont]=$dato;
                $cont++;
            }

        
        $data["length"]=$cont;
        
         
     
           
        $data["totale"]=$totale;
        return $data;
        }
    }

    protected function remove()
    {
        $request = request();
        if($request->has("link")&&$request->user==session("username"))
        {   $link=$request->link;
            $carrelloCorrente=Profilo::where("Username",session("username"))->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];

            Prodotto_carrello::where("prodotto",$link)->where("carrello",$carrelloCorrente)->delete();
            return 1;
        }
        return 0;

    }
    protected function change()
    {
        $request = request();
        if($request->has("quantita")&&$request->user==session("username")&&$request->has("prodotto"))
        {   $quantita=$request->quantita;
            $username=$request->user;
            $prodotto=$request->prodotto;
            $carrelloCorrente=Profilo::where("Username",$username)->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];

            Prodotto_carrello::where("prodotto",$prodotto)->where("carrello",$carrelloCorrente)->update(['quantita' => $quantita]);
            return 1;
        }
        return 0;

    }
    protected function eliminaCarrello()
    {
        $request = request();
        if($request->has("carrello")&&$request->user==session("username"))
        {
            Prodotto_carrello::where("carrello",$request->carrello)->delete();
            Carrello::where("id",$request->carrello)->delete();
            return 1;
        }
        return 0;
    }
    protected function pubblica()
    {
        $request = request();
        if($request->has("descrizione")&&$request->user==session("username")&&$request->has("titolo")&&$request->has("totale"))
        {   
            $descrizione=$request->descrizione;
            $username=$request->user;
            $totale=$request->totale;
            $titolo=$request->titolo;
            $carrelloCorrente=Profilo::where("Username",$username)->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];

            Carrello::create([
                'proprietario' => $username,
                'Totale' => $totale,
                'Nome' => $titolo,
                'Descrizione' => $descrizione,
                'likes' => '0',
            ]);      
            
            $max=Carrello::max("id");
            $dati=Prodotto_carrello::select("prodotto" ,DB::raw("$max as carrello"),"quantita")->where("carrello",$carrelloCorrente)->get();
            foreach($dati as $dato)
                Prodotto_carrello::create(['prodotto'=>$dato["prodotto"],'carrello'=>$dato["carrello"],'quantita'=>$dato["quantita"]]);
            Prodotto_carrello::where("carrello",$carrelloCorrente)->delete();
            
            return 1;
        }
        return 0;

    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::select("ImmagineProfilo as img")->where("Username",session("username"))->first();
            if($img["img"]!=null)
            {
                $img=$img["img"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('carrello',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return view('welcome');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("carrello",["img"=>$img,"username"=>session("username")]);
            }
        } 

}
?>