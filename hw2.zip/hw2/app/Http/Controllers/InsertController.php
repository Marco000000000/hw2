<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Prodotto_carrello;
use Illuminate\Support\Facades\Session;

class InsertController extends Controller {


    protected function local()
    {
        $request = request();
        if($request->has("link") &&$request->user==session("username"))
        {   $user=$request->user;
            $link=$request->link;

            $carrelloCorrente=Profilo::where("Username",$user)->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];
            $exist=Prodotto_carrello::where("prodotto",$link)->where("carrello",$carrelloCorrente)->exists();
            if(!$exist)
            {
                Prodotto_carrello::create([
                    'prodotto' => $link,
                    'carrello' => $carrelloCorrente
                ]);
                return 1;
            }      
            return 0;
        }
        return 0;        
        
    }
    protected function curl()
    {   
        $key="6ba0804b4e289ee35b3b2b36ad31ac7464eb0ae17d5e0cdb1015454fd8bed479";
        $url="https://serpapi.com/search.json?location=italy&engine=google&q=".session("cerca")."&tbm=shop&hl=it&gl=it&lr=it&google_domain=google.it&api_key=".$key;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        
        $result = curl_exec($curl);

        curl_close($curl);
        return $result;
    }

   
    
     

}
?>