<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Profilo extends Model {
    protected $connection = 'mongodb';
    protected $table = 'profilo';
    public $timestamps = false;
    protected $primaryKey="Username";
    public $incrementing=false;
    public $keyType = 'string';
    protected $fillable = [
        'Username', 'Password', 'Email','ImmagineProfilo','carrelloCorrente','seguaci'
    ];

    protected $hidden = [
        'Email', 'Password'
    ];

    protected $casts = [
        'seguaci' => 'int' ,
        
    ];
  
    public function carrello() {
        return $this->hasMany("App\Models\Carrello","proprietario","Username");
    }

}

?>