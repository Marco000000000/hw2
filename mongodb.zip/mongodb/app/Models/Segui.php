<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Segui extends Model {
    protected $connection = 'mongodb';

    protected $table = 'segui';
    public $timestamps = false;
    
    protected $fillable = [
        'seguace', 'seguito'
    ];


    public function profilo1() {
        return $this->belongsTo("App\Models\Profilo","seguito","Username");
    }
    public function profilo() {
        return $this->belongsTo("App\Models\Profilo","seguace","Username");
    }

}

?>