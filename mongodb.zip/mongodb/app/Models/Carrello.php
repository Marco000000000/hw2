<?php

namespace App\Models;


use Jenssegers\Mongodb\Eloquent\Model;

class Carrello extends Model {
    protected $connection = 'mongodb';
    protected $table = 'carrello';
    public $timestamps = false;
    protected $fillable = [
        'Totale','id', 'data' ,'proprietario','likes','Descrizione','Nome'
    ];


    

    public function profilo() {
        return $this->belongsTo("App\Models\Profilo","proprietario","Username");
    }

    public function prodotto_carrello()
    {
        return $this->hasMany("App\Models\Prodotto_carrello","carrello");

    }
    public function commenti() {
        return $this->hasMany("App\Models\Commenti","carrello");
    }
    public function piaciuti() {
        return $this->hasMany("App\Models\Piaciuti","carrello");
    }

}

?>