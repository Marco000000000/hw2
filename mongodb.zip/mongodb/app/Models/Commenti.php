<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;


class Commenti extends Model {
    protected $connection = 'mongodb';

    protected $table = 'commenti';
    public $timestamps = false;

    protected $fillable = [
        
        '_id', 'mittente', 'carrello', 'commento'
    ];

    public function Profilo() {
        return $this->belongsTo("App\Models\Profilo","mittente","Username");
    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","carrello");
    }
}

?>