<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Prodotti extends Model {
    protected $connection = 'mongodb';

    protected $table = 'prodotti';
    public $timestamps = false;
    protected $primaryKey="url";

    protected $fillable = [
        'url', 'Venditore', 'titolo','prezzo','UrlImg'
    ];


    public function prodotto_carrello() {
        return $this->hasMany("App\Models\Prodotto_carrello","prodotto","url");
    }



    
}

?>