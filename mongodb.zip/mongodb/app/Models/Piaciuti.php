<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Piaciuti extends Model {
    protected $connection = 'mongodb';

    protected $table = 'piaciuti';
    public $timestamps = false;
    protected $primarykey=["mittente","carrello"];
    public $incrementing=false;
    protected $fillable = [
        'mittente', 'carrello'
    ];


    public function profilo() {
        return $this->belongsTo("App\Models\Profilo","mittente","Username");
    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","carrello");
    }
}

?>