<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model;

class Prodotto_carrello extends Model {

    protected $connection = 'mongodb';

    public $timestamps = false;

    protected $table = 'prodotto-carrello';
    protected $fillable = [
        '_id','prodotto', 'carrello', 'quantita'
    ];




   
    public function prodotti(){
        
        return $this->belongsTo("App\Models\Prodotti",'prodotto',"url");

    }
    public function carrello() {
        return $this->belongsTo("App\Models\Carrello","carrello");
    }
}

?>