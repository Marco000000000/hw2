<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use Carbon\Carbon;
use App\Models\Prodotti;
use App\Models\Carrello;
use App\Models\Profilo;
use App\Models\Piaciuti;
use App\Models\Commenti;
use App\Models\Prodotto_carrello;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cookie;

class CarrelloController extends Controller {


    protected function data()
    {
        $request = request();
        if($request->username==session("username"))
        {
            $username=$request->username;
            $data=[];
            
            
            $res=Carrello::whereNull("Nome")->where("proprietario","$username")->first();
            $totale=0;
            $cont=0;
            foreach( $res->prodotto_carrello()->get() as $row)
            {    
                                 
                $rowprodotto=$row->prodotti()->first();
                $dato=[];
                $dato["Venditore"]=$rowprodotto["Venditore"];
                $dato["url"]=$row["prodotto"];
                $dato["UrlImg"]=$rowprodotto["UrlImg"];
                $dato["titolo"]=$rowprodotto["titolo"];
                $dato["prezzo"]=$rowprodotto["prezzo"];
                $dato["quantita"]=$row["quantita"];

        
                        
                $totale=$totale+$row["quantita"]*$rowprodotto["prezzo"];
                
                $data[$cont]=$dato;
                $cont++;
            }

        
        $data["length"]=$cont;
        
         
     
           
        $data["totale"]=$totale;
        return $data;
        }
    }

    protected function remove()
    {
        $request = request();
        if($request->has("link")&&$request->user==session("username"))
        {   $link=$request->link;
            $carrelloCorrente=Profilo::where("Username",session("username"))->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];
            return Prodotto_carrello::where("prodotto",$link)->where("carrello",$carrelloCorrente)->delete();
        }
        return 0;

    }
    protected function change()
    {
        $request = request();
        if($request->has("quantita")&&$request->user==session("username")&&$request->has("prodotto"))
        {   $quantita=$request->quantita;
            $username=$request->user;
            $prodotto=$request->prodotto;
            $carrelloCorrente=Profilo::where("Username",$username)->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];

            Prodotto_carrello::where("prodotto",$prodotto)->where("carrello",$carrelloCorrente)->update(['quantita' => $quantita]);
            return 1;
        }
        return 0;

    }
    protected function eliminaCarrello()
    {
        $request = request();
        if($request->has("carrello")&&$request->user==session("username"))
        {   
            Piaciuti::where("carrello",$request->carrello)->delete();
            Commenti::where("carrello",$request->carrello)->delete();
            Prodotto_carrello::where("carrello",$request->carrello)->delete();
            Carrello::find($request->carrello)->delete();
            return 1;
        }
        return 0;
    }
    protected function pubblica()
    {
        $request = request();
        if($request->has("descrizione")&&$request->user==session("username")&&$request->has("titolo")&&$request->has("totale"))
        {   
            $descrizione=$request->descrizione;
            $username=$request->user;
            $totale=$request->totale;
            $titolo=$request->titolo;
            $carrelloCorrente=Profilo::where("Username",$username)->first();
            $carrelloCorrente=$carrelloCorrente["carrelloCorrente"];

            $carrello=Carrello::create([
                'proprietario' => $username,
                'Totale' => $totale,
                'Nome' => $titolo,
                'Descrizione' => $descrizione,
                'likes' => 0,
                'data'=>Carbon::now()->toDateTimeString()
            ]);      
            

            $dati=Prodotto_carrello::select("prodotto" ,"quantita")->where("carrello",$carrelloCorrente)->get()->toArray();
            foreach($dati as $dato)
                Prodotto_carrello::create(['prodotto'=>$dato["prodotto"],'carrello'=>$carrello["_id"],'quantita'=>$dato["quantita"]]);
            Prodotto_carrello::where("carrello",$carrelloCorrente)->delete();
            
            return 1;
        }
        return 0;

    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::where("Username",session("username"))->first();
            if($img["ImmagineProfilo"]!=null)
            {
                $img=$img["ImmagineProfilo"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('carrello',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return view('welcome');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("carrello",["img"=>$img,"username"=>session("username")]);
            }
        } 

}
?>