<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Carrello;
use App\Models\Piaciuti;
/** */
use App\Models\Commenti;
use App\Models\Prodotto_carrello;
/**da togliere */
use App\Models\Segui;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class ProfileController extends Controller {


    protected function data()
    {
        $request = request();
         if($request->has("cerca")&&$request->has("opzione"))
         {  $query1="";
            $username=$request->cerca;
            $opzione=$request->opzione;
            $queryPrincipale=Profilo::where("Username",$username);
            if($queryPrincipale->exists())
            {   
                $row=$queryPrincipale->first();
                $username=$row["Username"];
                $imgprofilo=$row["ImmagineProfilo"];
            }
            else {
                if($request->cerca!="")
                    $queryalternativa=Carrello::whereNotNull("Nome")
                    ->where(function($query) use ($request){
                    $query ->where("Nome",'like',"%".$request->cerca."%")
                    ->orwhere("Descrizione","like","%".$request->cerca."%");
                        
                    })
                    ->orderBy('data', 'DESC')
                    ->orderBy('Totale', 'DESC');
                   
                else
                    return 0;
                
                
                if($queryalternativa->exists())
                {   
                    $row=$queryalternativa->first()->profilo()->first();
                    
                    $username=$row["Username"];
                    $imgprofilo=$row["ImmagineProfilo"];
                }
                else
                {
                    return 0;
                }

            }
            if($opzione=="pub")
            {
                $query1=Carrello::where("proprietario",$username)
                ->whereNotNull("Nome");
               
            }
            else{
                if($opzione=="like")
                    {$carrelli=Piaciuti::where("mittente",$username)->pluck("carrello");
                    
                    $query1=Carrello::whereIn("_id",$carrelli);
                
                }
                else
                    if($opzione=="follow")
                        {
                        $proprietario=Segui::select(["seguito"])->where("seguace",$username)->pluck("seguito");
                        
                        $query1=Carrello::whereIn("proprietario",$proprietario)->whereNotNull("Nome");
                    }
                    else
                        return 0;
            }

            if($request->has("carrelloAttuale"))
            {   
                $carrelloAttuale=Carrello::find($request->carrelloAttuale);
                $query1->where("data","<",$carrelloAttuale->data);
                    
            }
            $query1->orderBy("data","desc")->orderBy('Totale', 'DESC');
            $conta=Segui::where("seguito",$username)->count();
            $queryFollower=Segui::where("seguace",session("username"));
            $data=[];
            $data["follower"]=$conta;
            if($queryFollower->exists())
            {
                $data["followed"]=true;
            }
            else
            {
                $data["followed"]=false;

            }
            $data["imgProfilo"]=$imgprofilo;
            $data["username"]=$username;
            $contatore=0;
            $res=$query1->paginate(2);
            foreach( $res as $row)
            {   
                $ImmagineProfilo=Profilo::select("ImmagineProfilo")->where("Username",$row["proprietario"])->first();
                
                
                /*prodotto carrello quantita*/

                $dato["carrello"]=$row["_id"];
                $dato["ImmagineProfilo"]=$ImmagineProfilo;
                $dato["proprietario"]=$row["proprietario"];
                $dato["Totale"]=$row["Totale"];
                $dato["Nome"]=$row["Nome"];
                $dato["likes"]=$row["likes"];
                $dato["ImmagineProfilo"]=$ImmagineProfilo["ImmagineProfilo"];
                if(session("username")!=null)
                {
                    $reslike=Piaciuti::where("mittente",session("username"))->where("carrello",$row->_id)->exists();
                    if($reslike)
                    {
                        $dato["emoji"]="❤️";
                    }
                    else{
                        $dato["emoji"]="🤍";
                    }
                }
                $dato["tempo"]=$this->tempo($row->data);
                $resimg=Prodotto_carrello::where("carrello",$row->_id)->get();
               
                $foto=[];
                $link=[];
                $cont=0;
                foreach($resimg as $rowimg){
                    $link["url".$cont]=$rowimg["prodotto"];
                    $rowimg=$rowimg->prodotti()->first();
                    $foto["img".$cont]=$rowimg["UrlImg"];
                    
                    $cont++;
                }
                $dato["numElementi"]=$cont;
                $dato["foto"]=$foto;
                $dato["link"]=$link;
    
    
                $data[$contatore]=$dato;
                $contatore++;
    
            }
            $data["length"]=$contatore;
            return($data);
         }

         
    }

    public function cambiaFollow()
    {
        $request = request();
         if($request->has("seguito")&&session("username")!=null)
         {  $user=session("username");
            $seguito=$request->seguito;
            $exists= Segui::where("seguace",$user)->where("seguito",$seguito)->exists();
            if($user==$seguito)
            {
                return 0;
            }
            if(!$exists)
            {
                Segui::create(['seguace' => $user,
                'seguito' => $seguito]);
                
            }
            else
            {
                Segui::where("seguace",$user)->where("seguito",$seguito)->delete();
            }
            return 1;
        }
        return 0;

    } 

    public function follower($profilo)
    {   
        $followers=Segui::where("seguito",$profilo)->get();
        $dati=[];
        $i=0;
        foreach($followers as $follower)
        {   
            $dati[$i]["profilo"]=$follower["seguace"];
            $dati[$i]["immagineProfilo"]=$follower->profilo()->first()["ImmagineProfilo"];
            $i++;
        }
        return $dati;
    }
    public function uploadPhoto()
    {
        $request = request();
        if($request->hasFile("foto"))
        {   $url=session("username").".".$request->foto->extension();
            $valid_ext = array("jpg","png","jpeg","bmp","gif");

            if(in_array($request->foto->extension(),$valid_ext))
            {
                Profilo::where("Username",session("username"))->update(['ImmagineProfilo' => "upload/".$url]);
                $request->file("foto")->storeAs('upload',$url, 'public_uploads');
                return 1;
            }

       }
        return 0;
    }
    private function tempo($data)
    {
        $timestamp=strtotime($data);
        
        $strTime = array("s", "m", "h", "d", "m", "y");
        $length = array("60","60","24","30","12","10");

        $currentTime = time();
        if($currentTime >= $timestamp) {
            $diff     = time()- $timestamp;
            for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
            $diff = $diff / $length[$i];
            }

        $diff = round($diff);
        $diff=$diff . " " . $strTime[$i];
        return $diff;
    }
    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::where("Username",session("username"))->first();
            if($img["ImmagineProfilo"]!=null)
            {
                $img=$img["ImmagineProfilo"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('profilo',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return redirect('/');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("profilo");
            }
        } 

    
}
?>