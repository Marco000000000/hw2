<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Prodotti;
use App\Models\Commenti;
use App\Models\Carrello;

use Illuminate\Support\Facades\Session;

class OverlayController extends Controller {


    protected function create()
    {
        $request = request();
        $id=$request->id;
        $res=Carrello::find($id);
        $data=[];
        $totale=0;
        $cont=0;
        
        foreach($res->prodotto_carrello()->get() as $row)
        {   
            $rowprodotto=$row->prodotti()->first();
            $data["titolo"]=$res["Nome"];
            $data["descrizione"]=$res["Descrizione"];
            $dato=[];
            $dato["Venditore"]=$rowprodotto["Venditore"];
            $dato["url"]=$row["prodotto"];
            $dato["UrlImg"]=$rowprodotto["UrlImg"];
            $dato["titolo"]=$rowprodotto["titolo"];
            $dato["prezzo"]=$rowprodotto["prezzo"];
            $dato["quantita"]=$row["quantita"];

                    
            $totale=$totale+$row["quantita"]*$rowprodotto["prezzo"];
                    
            $data[$cont]=$dato;
            $cont++;
        }

        $data["length"]=$cont;
        $res=Commenti::where("carrello",$id)->get();
        $commenti=[];
        $cont=0;
        foreach($res as $row)
            {  
                $commento["id"]=$row["_id"];
                $commento["mittente"]=$row["mittente"];
                $commento["commento"]=$row["commento"];
                
                $commenti[$cont]=$commento;
                $cont++;
            }
        $commenti["length"]=$cont;
        $data["commenti"]=$commenti;
        $data["totale"]=number_format($totale,2);

        return($data);
        
    }

   
    
     

}
?>