<?php
namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use App\Models\Profilo;
use App\Models\Carrello;
use App\Models\Piaciuti;
use App\Models\Prodotti;
use App\Models\Prodotto_carrello;
use Illuminate\Support\Facades\Cookie;

use Illuminate\Support\Facades\Session;

class HomeController extends Controller {


    protected function data()
    {
        $request = request();
        if($request->cerca!="")
            $res=Carrello::whereNotNull("Nome")
                    ->where(function($query) use ($request){
                        $query ->where("Nome",'like',"%".$request->cerca."%")
                        ->orwhere("Descrizione","like","%".$request->cerca."%");
                            
                        })
                    ->orderBy("data","desc");
                    
        else
            $res=Carrello::whereNotNull("Nome")->orderBy("data","desc");
        $data=[];
           if($request->has("carrelloAttuale"))
            {   
                $carrelloAttuale=Carrello::find($request->carrelloAttuale);
                $res->where("data","<",$carrelloAttuale->data);
                    
            }
            $res=$res->paginate(2);
        $contatore=0;
        foreach($res as $row)
        {   $dato=[];
            
            
            $ImmagineProfilo=Profilo::select("ImmagineProfilo")
            ->where("Username",$row["proprietario"])->first();
            $dato["carrello"]=$row["_id"];
            $dato["ImmagineProfilo"]=$ImmagineProfilo;
            $dato["proprietario"]=$row["proprietario"];
            $dato["Totale"]=$row["Totale"];
            $dato["Nome"]=$row["Nome"];
            $dato["likes"]=$row["likes"];
            $dato["ImmagineProfilo"]=$ImmagineProfilo["ImmagineProfilo"];
            if(session("username")!=null)
            {
                $reslike=Piaciuti::where("mittente",session("username"))->where("carrello",$row["_id"])->exists();
                if($reslike)
                {
                    $dato["emoji"]="❤️";
                }
                else{
                    $dato["emoji"]="🤍";
                }
            }
            $dato["tempo"]=$this->tempo($row["data"]);
            
           

            
            $resimg=Prodotto_carrello::where("carrello",$row["_id"])->get();

            $foto=[];
            $link=[];
            $cont=0;
            foreach($resimg as $rowimg){
                $link["url".$cont]=$rowimg["prodotto"];
                    $rowimg=$rowimg->prodotti()->first();
                    $foto["img".$cont]=$rowimg["UrlImg"];
                    
                    $cont++;
            }
            $dato["numElementi"]=$cont;
            $dato["foto"]=$foto;
            $dato["link"]=$link;


            $data[$contatore]=$dato;
            $contatore++;

        }
        return($data);
        
    }

   
    private function tempo($data)
    {
        $timestamp=strtotime($data);
        
        $strTime = array("s", "m", "h", "d", "m", "y");
        $length = array("60","60","24","30","12","10");

        $currentTime = time();
        if($currentTime >= $timestamp) {
            $diff     = time()- $timestamp;
            for($i = 0; $diff >= $length[$i] && $i < count($length)-1; $i++) {
            $diff = $diff / $length[$i];
            }

        $diff = round($diff);
        $diff=$diff . " " . $strTime[$i];
        return $diff;
    }
    }
    public function index() {
        if(session("username")!=null)
        {
            $img=Profilo::where("Username",session("username"))->first();
            if($img["ImmagineProfilo"]!=null)
            {
                $img=$img["ImmagineProfilo"];
            }
            else
            {
                $img="Images/profilo-vuoto.png";
            }
            return view('home',["img"=>$img,"username"=>session("username")]);   
        }   
        else
        if(Cookie::get('username')==null)
                return redirect('/');
            else
            {
                Session::put('username', Cookie::get('username'));
                return redirect("home");
            }
        } 

}
?>