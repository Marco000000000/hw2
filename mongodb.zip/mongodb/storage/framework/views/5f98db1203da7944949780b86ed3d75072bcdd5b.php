  
<?php $__env->startSection("placeholder"); ?>
"Cerca Prodotto"
<?php $__env->stopSection(); ?>
<?php $__env->startSection("action"); ?>
/Ricerca
<?php $__env->stopSection(); ?>
<?php $__env->startSection("titolo"); ?>
<title>
        Ricerca
</title>
<?php $__env->stopSection(); ?>  
<?php $__env->startSection("css_js"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/Ricerca.css')); ?>">
    <script src=" <?php echo e(asset('js/Ricerca.js')); ?>" defer="true"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("corpo"); ?>
<article>

        
    <img id="caricamento" src="images/caricamento.gif">
        
        
        
    </article>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.page', ['img' => $img,"username"=>$username], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Utente\provalaravel\mongodb\resources\views/Ricerca.blade.php ENDPATH**/ ?>