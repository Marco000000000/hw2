<html><head>
    <title>
        Login
    </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/Login.css')); ?>">

<body>
    
    <div id="Container">
        <div id="overlay">
            <h1>Accedi</h1>
            <div class="errori">
            
            <?php echo $error; ?>

            </div>
    <form action="<?php echo e(route('control')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label><input type="text" placeholder="Nome Utente/Email" name="utente" required></label>
        <label><input type="password" placeholder="Password" name="password" required></label>
        <label id="label_check"><input id="checkbox" type="checkbox" placeholder="" name="check"><p>Resta collegato</p></label>
        <label id="submit"><input type="submit" value="Accedi"></label>
    </form>
    <a href="/register"> <h3>Non hai un account?<br>Registrati</h3></a>
    </div>
    </div>
 


        </body></html><?php /**PATH C:\Users\Utente\provalaravel\mongodb\resources\views/login.blade.php ENDPATH**/ ?>