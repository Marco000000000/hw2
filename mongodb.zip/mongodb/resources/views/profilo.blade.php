@extends('layouts.page', ['img' => $img,"username"=>$username])  
@section("placeholder")
"Cerca persona o argomento"
@endsection
@section("action")
""
@endsection
@section("titolo")
<title>
        Profilo
</title>
@endsection  
@section("css_js")
    <link rel="stylesheet" href="{{ asset('css/overlay.css') }}">
    <link rel="stylesheet" href="{{ asset('css/Profilo.css') }}">
    <script src=" {{asset('js/Profilo.js')}}" defer="true"></script>
@endsection
@section("corpo")
<header>
        <div class="profilo">
            <form target="_myFrame" action="" method="post">
            @csrf
            <label><input class="hidden" name="foto" type="file"></input><img class="manina" src="{{$img}}"></label>
            
            </form>
            <div class="dati">
                <h1> {{$username}}</h1>
                <div class="segui">
                    <p></p>
                    <button class="hidden"><strong>👤</strong></button>
                </div>
                
            </div>
        </div>
        <div class="scelta">
            <div id="pub" class="selected"><a >Pubblicati</a></div>
            <div id="like"><a>Piaciuti</a></div>
            <div id="follow"><a>Seguiti</a></div>
            
        </div>

    </header>
    <article>
    


         
    </article>
@endsection










