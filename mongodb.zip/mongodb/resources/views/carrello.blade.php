@extends('layouts.page', ['img' => $img,"username"=>$username])  
@section("placeholder")
"Cerca Prodotto"
@endsection
@section("action")
/Ricerca
@endsection
@section("titolo")
<title>
        Carrello
</title>
@endsection  
@section("css_js")
    <link rel="stylesheet" href="{{ asset('css/Carrello.css') }}">
    <script src=" {{asset('js/Carrello.js')}}" defer="true"></script>
@endsection
@section("corpo")
<article>
        
        <div class="divisore">
       
        </div>


         <section class="totale">
            <div>
                <p>
                    <strong>Totale:&nbsp</strong><em><?php ?>€</em>
                </p>
            </div>
            <div class="pubblica">
                <p class="errore hidden">Superato il limite dei 255 caratteri</p>
                <form>
                <input row="2"  id="nome" name="nome" type="text" placeholder="Nome carrello" required>
                <textarea id="descrizione" name="descrizione" placeholder="Descrizione" rows="10" cols="50" required></textarea>
                <input id="pubblica" name="pubblica" type="submit" value="Pubblica">

                
            </form>
            </div>
            
        </section>
        
    </article>
@endsection




